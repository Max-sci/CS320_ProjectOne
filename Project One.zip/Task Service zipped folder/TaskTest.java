/**
 * Maxwell J. Sciola
 * Unit tests for the Task class.
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("001", "Test Task", "This is a test task.");
        assertEquals("001", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task.", task.getDescription());
    }

    @Test
    public void testInvalidTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
    }

    @Test
    public void testInvalidNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", "This name is way too long", "Description");
        });
    }

    @Test
    public void testInvalidDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", "Name", "This description is way too long for the allowed limit of fifty characters.");
        });
    }

    @Test
    public void testSetNameValid() {
        Task task = new Task("001", "Task", "Description");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    @Test
    public void testSetDescriptionValid() {
        Task task = new Task("001", "Task", "Description");
        task.setDescription("Updated description.");
        assertEquals("Updated description.", task.getDescription());
    }
}
