/**
 * Maxwell J. Sciola
 * Unit tests for the TaskService class.
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddTaskSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("001", "Task1", "Description1");
        service.addTask(task);
    }

    @Test
    public void testAddTaskDuplicateId() {
        TaskService service = new TaskService();
        Task task1 = new Task("001", "Task1", "Description1");
        Task task2 = new Task("001", "Task2", "Description2");
        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
    }

    @Test
    public void testDeleteTaskSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("001", "Task", "Description");
        service.addTask(task);
        service.deleteTask("001");
    }

    @Test
    public void testDeleteTaskNotFound() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
    }

    @Test
    public void testUpdateTaskNameSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("001", "Task", "Description");
        service.addTask(task);
        service.updateTaskName("001", "Updated Name");
        assertEquals("Updated Name", task.getName());
    }

    @Test
    public void testUpdateTaskDescriptionSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("001", "Task", "Description");
        service.addTask(task);
        service.updateTaskDescription("001", "Updated Description");
        assertEquals("Updated Description", task.getDescription());
    }
}
