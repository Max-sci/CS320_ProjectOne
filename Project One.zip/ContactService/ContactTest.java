// Maxwell J. Sciola

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Unit tests for the Contact class
public class ContactTest {

    @Test
    public void testValidContactCreation() {
        // Create a valid contact and check that the first name is stored correctly
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("John", contact.getFirstName());
    }

    @Test
    public void testInvalidPhoneLength() {
        // Try creating a contact with a short phone number - should throw an error
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "12345", "123 Main St");
        });
    }

    @Test
    public void testUpdateFirstName() {
        // Update the first name and check that it was changed
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }
}