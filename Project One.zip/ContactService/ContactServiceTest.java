// Maxwell J. Sciola

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Unit tests for the ContactService class
public class ContactServiceTest {

    @Test
    public void testAddContact() {
        // Create a service and add a contact
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "Jane", "Smith", "1234567890", "456 Main St");
        service.addContact(contact);

        // Make sure the contact was added correctly
        assertEquals("Jane", service.getContact("001").getFirstName());
    }

    @Test
    public void testDeleteContact() {
        // Add a contact and then delete it
        ContactService service = new ContactService();
        Contact contact = new Contact("002", "Mike", "Jones", "0987654321", "789 Oak St");
        service.addContact(contact);
        service.deleteContact("002");

        // After deletion, the contact should be null
        assertNull(service.getContact("002"));
    }

    @Test
    public void testUpdatePhone() {
        // Add a contact, update the phone number, and verify the update
        ContactService service = new ContactService();
        Contact contact = new Contact("003", "Anna", "Lee", "1234567890", "321 Pine St");
        service.addContact(contact);
        service.updatePhone("003", "0987654321");

        // Check that the new phone number is stored
        assertEquals("0987654321", service.getContact("003").getPhone());
    }
}