// Maxwell J. Sciola

// This class represents a contact with basic info like ID, name, phone number, and address.
public class Contact {

    // Contact ID (can't be changed once it's set)
    private final String contactId;

    // First name of the contact
    private String firstName;

    // Last name of the contact
    private String lastName;

    // Phone number (should be 10 digits)
    private String phone;

    // Address (up to 30 characters)
    private String address;

    // Constructor to create a new Contact object with validation
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        // Validate each input field before assigning values
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }

        // Set values if all checks pass
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Returns the contact ID (read-only)
    public String getContactId() {
        return contactId;
    }

    // Returns the first name
    public String getFirstName() {
        return firstName;
    }

    // Updates the first name (only if it's valid)
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
        this.firstName = firstName;
    }

    // Returns the last name
    public String getLastName() {
        return lastName;
    }

    // Updates the last name (only if it's valid)
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        this.lastName = lastName;
    }

    // Returns the phone number
    public String getPhone() {
        return phone;
    }

    // Updates the phone number (must be 10 digits)
    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        this.phone = phone;
    }

    // Returns the address
    public String getAddress() {
        return address;
    }

    // Updates the address (must be 30 characters or fewer)
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }
        this.address = address;
    }
}