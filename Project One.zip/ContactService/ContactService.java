// Maxwell J. Sciola

import java.util.*;

// This class handles managing a list of contacts (adding, deleting, updating)
public class ContactService {

    // Stores contacts using a map with the contact ID as the key
    private final Map<String, Contact> contacts = new HashMap<>();

    // Adds a new contact to the list
    public void addContact(Contact contact) {
        // Make sure the contact ID is unique
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Duplicate contact ID");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Deletes a contact based on their ID
    public void deleteContact(String contactId) {
        // Check if the contact exists before trying to delete
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contactId);
    }

    // Updates only the first name of the contact
    public void updateFirstName(String contactId, String firstName) {
        contacts.get(contactId).setFirstName(firstName);
    }

    // Updates only the last name of the contact
    public void updateLastName(String contactId, String lastName) {
        contacts.get(contactId).setLastName(lastName);
    }

    // Updates only the phone number of the contact
    public void updatePhone(String contactId, String phone) {
        contacts.get(contactId).setPhone(phone);
    }

    // Updates only the address of the contact
    public void updateAddress(String contactId, String address) {
        contacts.get(contactId).setAddress(address);
    }

    // Returns the contact object for a given ID (null if it doesn't exist)
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}